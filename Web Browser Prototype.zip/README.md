
  # Web Browser Prototype

  This is a code bundle for Web Browser Prototype. The original project is available at https://www.figma.com/design/hr9fTfYNesbOiE4AlJQd36/Web-Browser-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  