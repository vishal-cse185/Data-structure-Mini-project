import { useState, useEffect } from "react";
import { StackVisualizer } from "./components/StackVisualizer";
import { QueueVisualizer } from "./components/QueueVisualizer";
import { CurrentPageDisplay } from "./components/CurrentPageDisplay";
import { OperationsLog } from "./components/OperationsLog";
import { StatisticsPanel } from "./components/StatisticsPanel";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "./components/ui/dialog";
import { Card } from "./components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { ArrowLeft, ArrowRight, History, Plus, Play, ExternalLink, RotateCcw, Zap, Keyboard } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { Toaster } from "./components/ui/sonner";
import { Badge } from "./components/ui/badge";

interface Operation {
  id: number;
  type: string;
  description: string;
  timestamp: string;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>("https://example.com");
  const [backStack, setBackStack] = useState<string[]>([]);
  const [forwardStack, setForwardStack] = useState<string[]>([]);
  const [crawlerQueue, setCrawlerQueue] = useState<string[]>([]);
  const [operations, setOperations] = useState<Operation[]>([]);
  const [operationCounter, setOperationCounter] = useState(0);
  
  const [visitDialogOpen, setVisitDialogOpen] = useState(false);
  const [crawlDialogOpen, setCrawlDialogOpen] = useState(false);
  const [shortcutsDialogOpen, setShortcutsDialogOpen] = useState(false);
  const [newUrl, setNewUrl] = useState("");
  const [newCrawlUrl, setNewCrawlUrl] = useState("");

  const addOperation = (type: string, description: string) => {
    const newOp: Operation = {
      id: operationCounter,
      type,
      description,
      timestamp: new Date().toLocaleTimeString()
    };
    setOperations([newOp, ...operations].slice(0, 50)); // Keep last 50 operations
    setOperationCounter(operationCounter + 1);
  };

  const visitPage = (url: string) => {
    if (!url.trim()) {
      toast.error("Please enter a valid URL");
      return;
    }
    
    // Push current page to back stack
    setBackStack([...backStack, currentPage]);
    // Clear forward stack
    setForwardStack([]);
    // Set new current page
    setCurrentPage(url);
    setVisitDialogOpen(false);
    setNewUrl("");
    
    addOperation("visit", `Visited "${url}" - Pushed current to Back Stack, cleared Forward Stack`);
    toast.success(`Visited: ${url}`, {
      description: "Current page pushed to Back Stack, Forward Stack cleared"
    });
  };

  const goBack = () => {
    if (backStack.length === 0) {
      toast.error("No pages in Back Stack");
      return;
    }
    
    // Pop from back stack
    const previousPage = backStack[backStack.length - 1];
    const newBackStack = backStack.slice(0, -1);
    
    // Push current to forward stack
    setForwardStack([...forwardStack, currentPage]);
    setBackStack(newBackStack);
    setCurrentPage(previousPage);
    
    addOperation("back", `Went back to "${previousPage}" - Popped from Back Stack, pushed to Forward Stack`);
    toast.success("Went back", {
      description: "Popped from Back Stack, pushed to Forward Stack"
    });
  };

  const goForward = () => {
    if (forwardStack.length === 0) {
      toast.error("No pages in Forward Stack");
      return;
    }
    
    // Pop from forward stack
    const nextPage = forwardStack[forwardStack.length - 1];
    const newForwardStack = forwardStack.slice(0, -1);
    
    // Push current to back stack
    setBackStack([...backStack, currentPage]);
    setForwardStack(newForwardStack);
    setCurrentPage(nextPage);
    
    addOperation("forward", `Went forward to "${nextPage}" - Popped from Forward Stack, pushed to Back Stack`);
    toast.success("Went forward", {
      description: "Popped from Forward Stack, pushed to Back Stack"
    });
  };

  const addToCrawlQueue = (url: string) => {
    if (!url.trim()) {
      toast.error("Please enter a valid URL");
      return;
    }
    
    // Enqueue to crawler queue
    setCrawlerQueue([...crawlerQueue, url]);
    setCrawlDialogOpen(false);
    setNewCrawlUrl("");
    
    addOperation("enqueue", `Added "${url}" to Crawler Queue - Enqueued at rear`);
    toast.success(`Added to Crawler Queue: ${url}`, {
      description: "Enqueued at rear of queue"
    });
  };

  const crawlNext = () => {
    if (crawlerQueue.length === 0) {
      toast.error("Crawler Queue is empty");
      return;
    }
    
    // Dequeue from crawler queue
    const [nextUrl, ...remainingQueue] = crawlerQueue;
    
    // Push current page to back stack
    setBackStack([...backStack, currentPage]);
    // Clear forward stack
    setForwardStack([]);
    // Set crawled page as current
    setCurrentPage(nextUrl);
    setCrawlerQueue(remainingQueue);
    
    addOperation("crawl", `Crawled "${nextUrl}" - Dequeued from front, pushed to Back Stack`);
    toast.success(`Crawled: ${nextUrl}`, {
      description: "Dequeued from front, pushed to Back Stack"
    });
  };

  const loadDemoData = () => {
    setCurrentPage("https://wikipedia.org");
    setBackStack([
      "https://google.com",
      "https://github.com",
      "https://stackoverflow.com"
    ]);
    setForwardStack([]);
    setCrawlerQueue([
      "https://docs.python.org",
      "https://reactjs.org",
      "https://nodejs.org"
    ]);
    setOperations([]);
    setOperationCounter(0);
    
    addOperation("demo", "Loaded demo data with sample URLs");
    toast.success("Demo data loaded!", {
      description: "Try navigating back/forward or crawling queue items"
    });
  };

  const resetAll = () => {
    setCurrentPage("https://example.com");
    setBackStack([]);
    setForwardStack([]);
    setCrawlerQueue([]);
    setOperations([]);
    setOperationCounter(0);
    
    toast.success("Reset complete", {
      description: "All stacks and queues cleared"
    });
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Alt + Left Arrow = Back
      if (e.altKey && e.key === 'ArrowLeft') {
        e.preventDefault();
        goBack();
      }
      // Alt + Right Arrow = Forward
      else if (e.altKey && e.key === 'ArrowRight') {
        e.preventDefault();
        goForward();
      }
      // Alt + V = Visit
      else if (e.altKey && e.key === 'v') {
        e.preventDefault();
        setVisitDialogOpen(true);
      }
      // Alt + Q = Add to Queue
      else if (e.altKey && e.key === 'q') {
        e.preventDefault();
        setCrawlDialogOpen(true);
      }
      // Alt + C = Crawl Next
      else if (e.altKey && e.key === 'c') {
        e.preventDefault();
        crawlNext();
      }
      // Alt + R = Reset
      else if (e.altKey && e.key === 'r') {
        e.preventDefault();
        resetAll();
      }
      // Alt + D = Demo Data
      else if (e.altKey && e.key === 'd') {
        e.preventDefault();
        loadDemoData();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [backStack, forwardStack, crawlerQueue, currentPage]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 p-4 md:p-6">
      <Toaster />
      
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1>Web Browser & Crawler System</h1>
          <p className="text-muted-foreground">Interactive Data Structure Visualization (Stack + Queue)</p>
          <div className="flex gap-2 justify-center flex-wrap">
            <Badge variant="outline" className="gap-1">
              <Keyboard className="w-3 h-3" />
              Keyboard Shortcuts Enabled
            </Badge>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setShortcutsDialogOpen(true)}
              className="gap-1 h-6"
            >
              View Shortcuts
            </Button>
          </div>
        </div>

        {/* Current Page */}
        <CurrentPageDisplay url={currentPage} />

        {/* Control Panel */}
        <Card className="p-4 md:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3>Control Panel</h3>
            <div className="flex gap-2">
              <Button 
                onClick={loadDemoData} 
                variant="outline" 
                size="sm"
                className="gap-2"
              >
                <Zap className="w-4 h-4" />
                Load Demo
              </Button>
              <Button 
                onClick={resetAll} 
                variant="outline" 
                size="sm"
                className="gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Reset
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <Button onClick={() => setVisitDialogOpen(true)} className="gap-2">
              <ExternalLink className="w-4 h-4" />
              Visit Page
              <kbd className="hidden md:inline ml-1 px-1.5 py-0.5 text-xs bg-black/10 dark:bg-white/10 rounded">Alt+V</kbd>
            </Button>
            <Button 
              onClick={goBack} 
              variant="outline"
              disabled={backStack.length === 0}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
              <kbd className="hidden md:inline ml-1 px-1.5 py-0.5 text-xs bg-black/10 dark:bg-white/10 rounded">Alt+←</kbd>
            </Button>
            <Button 
              onClick={goForward} 
              variant="outline"
              disabled={forwardStack.length === 0}
              className="gap-2"
            >
              <ArrowRight className="w-4 h-4" />
              Forward
              <kbd className="hidden md:inline ml-1 px-1.5 py-0.5 text-xs bg-black/10 dark:bg-white/10 rounded">Alt+→</kbd>
            </Button>
            <Button 
              onClick={() => setCrawlDialogOpen(true)} 
              variant="secondary"
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              Add to Queue
              <kbd className="hidden md:inline ml-1 px-1.5 py-0.5 text-xs bg-black/10 dark:bg-white/10 rounded">Alt+Q</kbd>
            </Button>
            <Button 
              onClick={crawlNext} 
              variant="secondary"
              disabled={crawlerQueue.length === 0}
              className="gap-2"
            >
              <Play className="w-4 h-4" />
              Crawl Next
              <kbd className="hidden md:inline ml-1 px-1.5 py-0.5 text-xs bg-black/10 dark:bg-white/10 rounded">Alt+C</kbd>
            </Button>
          </div>
        </Card>

        {/* Statistics */}
        <StatisticsPanel 
          backStackSize={backStack.length}
          forwardStackSize={forwardStack.length}
          queueSize={crawlerQueue.length}
          totalOperations={operationCounter}
        />

        {/* Visualizations */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3">
            <TabsTrigger value="all">All Views</TabsTrigger>
            <TabsTrigger value="history">
              <History className="w-4 h-4 mr-2" />
              Browser History
            </TabsTrigger>
            <TabsTrigger value="log">Operations Log</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6 mt-6">
            {/* History Stacks */}
            <Card className="p-4 md:p-6">
              <h2 className="mb-6 text-center">Browser History (Stacks - LIFO)</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <StackVisualizer 
                  items={backStack}
                  title="Back Stack"
                  color="#10b981"
                  emptyMessage="No pages visited yet"
                />
                <StackVisualizer 
                  items={forwardStack}
                  title="Forward Stack"
                  color="#f59e0b"
                  emptyMessage="No forward history"
                />
              </div>
            </Card>

            {/* Crawler Queue */}
            <Card className="p-4 md:p-6">
              <h2 className="mb-6 text-center">Crawler Queue (FIFO)</h2>
              <QueueVisualizer 
                items={crawlerQueue}
                title="URLs Waiting to be Crawled"
                color="#8b5cf6"
                emptyMessage="No URLs in crawler queue"
              />
            </Card>

            {/* Operations Log */}
            <OperationsLog operations={operations} />
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <Card className="p-4 md:p-6">
              <h2 className="mb-6 text-center">Browser History (Stacks - LIFO)</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <StackVisualizer 
                  items={backStack}
                  title="Back Stack"
                  color="#10b981"
                  emptyMessage="No pages visited yet"
                />
                <StackVisualizer 
                  items={forwardStack}
                  title="Forward Stack"
                  color="#f59e0b"
                  emptyMessage="No forward history"
                />
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="log" className="mt-6">
            <OperationsLog operations={operations} />
          </TabsContent>
        </Tabs>

        {/* Legend */}
        <Card className="p-4">
          <h4 className="mb-3">Data Structure Reference</h4>
          <div className="flex flex-wrap gap-4 justify-center">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#10b981' }}></div>
              <span className="text-sm">Back Stack (LIFO - Last In First Out)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#f59e0b' }}></div>
              <span className="text-sm">Forward Stack (LIFO - Last In First Out)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#8b5cf6' }}></div>
              <span className="text-sm">Crawler Queue (FIFO - First In First Out)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-blue-400"></div>
              <span className="text-sm">Current Page</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Visit Page Dialog */}
      <Dialog open={visitDialogOpen} onOpenChange={setVisitDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Visit New Page</DialogTitle>
            <DialogDescription>
              Enter a URL to visit. This will push the current page onto the Back Stack and clear the Forward Stack.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Input 
              placeholder="https://example.com"
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && visitPage(newUrl)}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setVisitDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => visitPage(newUrl)}>
              Visit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add to Crawler Queue Dialog */}
      <Dialog open={crawlDialogOpen} onOpenChange={setCrawlDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add URL to Crawler Queue</DialogTitle>
            <DialogDescription>
              Enter a URL to add to the crawler queue. It will be enqueued at the rear.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Input 
              placeholder="https://example.com/page"
              value={newCrawlUrl}
              onChange={(e) => setNewCrawlUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addToCrawlQueue(newCrawlUrl)}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCrawlDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => addToCrawlQueue(newCrawlUrl)}>
              Add to Queue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Keyboard Shortcuts Dialog */}
      <Dialog open={shortcutsDialogOpen} onOpenChange={setShortcutsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Keyboard Shortcuts</DialogTitle>
            <DialogDescription>
              Speed up your presentation with these keyboard shortcuts
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <div className="flex justify-between items-center">
              <span>Visit New Page</span>
              <kbd className="px-2 py-1 bg-muted rounded text-sm">Alt + V</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span>Go Back</span>
              <kbd className="px-2 py-1 bg-muted rounded text-sm">Alt + ←</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span>Go Forward</span>
              <kbd className="px-2 py-1 bg-muted rounded text-sm">Alt + →</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span>Add to Crawler Queue</span>
              <kbd className="px-2 py-1 bg-muted rounded text-sm">Alt + Q</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span>Crawl Next URL</span>
              <kbd className="px-2 py-1 bg-muted rounded text-sm">Alt + C</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span>Load Demo Data</span>
              <kbd className="px-2 py-1 bg-muted rounded text-sm">Alt + D</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span>Reset All</span>
              <kbd className="px-2 py-1 bg-muted rounded text-sm">Alt + R</kbd>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setShortcutsDialogOpen(false)}>
              Got it!
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
