import { Globe } from "lucide-react";
import { Card } from "./ui/card";
import { motion } from "motion/react";

interface CurrentPageDisplayProps {
  url: string;
}

export function CurrentPageDisplay({ url }: CurrentPageDisplayProps) {
  return (
    <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-2 border-blue-400 overflow-hidden">
      <div className="flex items-center gap-3 justify-center">
        <Globe className="w-6 h-6 text-blue-600 dark:text-blue-400" />
        <div className="flex flex-col">
          <span className="text-sm text-muted-foreground">Current Page</span>
          <motion.p
            key={url}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="text-blue-600 dark:text-blue-400 break-all"
          >
            {url}
          </motion.p>
        </div>
      </div>
    </Card>
  );
}
