import { ArrowDown, ArrowUp } from "lucide-react";
import { Card } from "./ui/card";
import { motion, AnimatePresence } from "motion/react";

interface StackVisualizerProps {
  items: string[];
  title: string;
  color: string;
  emptyMessage: string;
}

export function StackVisualizer({ items, title, color, emptyMessage }: StackVisualizerProps) {
  return (
    <div className="flex flex-col items-center gap-3">
      <h3 className="text-center">{title}</h3>
      <div className="flex flex-col items-center gap-2 min-h-[200px] p-4 rounded-lg border-2 border-dashed" style={{ borderColor: color }}>
        {items.length === 0 ? (
          <p className="text-muted-foreground text-center mt-20">{emptyMessage}</p>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-2">
              <ArrowDown className="w-4 h-4" style={{ color }} />
              <span className="text-sm" style={{ color }}>Push/Pop</span>
              <ArrowUp className="w-4 h-4" style={{ color }} />
            </div>
            <AnimatePresence mode="popLayout">
              {[...items].reverse().map((item, index) => (
                <motion.div
                  key={`${item}-${items.length - index}`}
                  initial={{ opacity: 0, scale: 0.8, y: -20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: -20 }}
                  transition={{ duration: 0.3 }}
                  layout
                >
                  <Card 
                    className="px-4 py-3 w-48 text-center transition-all hover:scale-105"
                    style={{ 
                      backgroundColor: color + '20',
                      borderColor: color,
                      borderWidth: '2px'
                    }}
                  >
                    <p className="truncate">{item}</p>
                    {index === 0 && (
                      <span className="text-xs opacity-60">← Top</span>
                    )}
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </>
        )}
      </div>
    </div>
  );
}
