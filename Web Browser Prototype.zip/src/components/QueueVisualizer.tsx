import { ArrowRight } from "lucide-react";
import { Card } from "./ui/card";
import { motion, AnimatePresence } from "motion/react";

interface QueueVisualizerProps {
  items: string[];
  title: string;
  color: string;
  emptyMessage: string;
}

export function QueueVisualizer({ items, title, color, emptyMessage }: QueueVisualizerProps) {
  return (
    <div className="flex flex-col gap-3">
      <h3 className="text-center">{title}</h3>
      <div className="flex flex-col gap-3 p-4 rounded-lg border-2 border-dashed min-h-[150px]" style={{ borderColor: color }}>
        {items.length === 0 ? (
          <p className="text-muted-foreground text-center mt-12">{emptyMessage}</p>
        ) : (
          <>
            <div className="flex items-center gap-2 justify-center">
              <span className="text-sm" style={{ color }}>Front</span>
              <ArrowRight className="w-4 h-4" style={{ color }} />
              <span className="text-sm" style={{ color }}>Enqueue/Dequeue</span>
              <ArrowRight className="w-4 h-4" style={{ color }} />
              <span className="text-sm" style={{ color }}>Rear</span>
            </div>
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              <AnimatePresence mode="popLayout">
                {items.map((item, index) => (
                  <motion.div
                    key={`${item}-${index}`}
                    initial={{ opacity: 0, scale: 0.8, x: -20 }}
                    animate={{ opacity: 1, scale: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.8, x: -20 }}
                    transition={{ duration: 0.3 }}
                    layout
                  >
                    <Card 
                      className="px-4 py-3 min-w-[180px] text-center transition-all hover:scale-105 flex-shrink-0"
                      style={{ 
                        backgroundColor: color + '20',
                        borderColor: color,
                        borderWidth: '2px'
                      }}
                    >
                      <p className="truncate">{item}</p>
                      {index === 0 && (
                        <span className="text-xs opacity-60">← Front</span>
                      )}
                      {index === items.length - 1 && (
                        <span className="text-xs opacity-60">Rear →</span>
                      )}
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
