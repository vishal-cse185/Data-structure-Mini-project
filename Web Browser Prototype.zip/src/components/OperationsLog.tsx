import { Card } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";
import { Clock } from "lucide-react";
import { motion } from "motion/react";

interface Operation {
  id: number;
  type: string;
  description: string;
  timestamp: string;
}

interface OperationsLogProps {
  operations: Operation[];
}

export function OperationsLog({ operations }: OperationsLogProps) {
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3">
        <Clock className="w-4 h-4" />
        <h4>Operations Log</h4>
      </div>
      <ScrollArea className="h-[200px]">
        <div className="space-y-2">
          {operations.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No operations yet</p>
          ) : (
            operations.map((op) => (
              <motion.div
                key={op.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-sm p-2 rounded bg-muted/50"
              >
                <div className="flex justify-between items-start gap-2">
                  <span className="flex-1">{op.description}</span>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">{op.timestamp}</span>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}
