import { Card } from "./ui/card";
import { BarChart3 } from "lucide-react";

interface StatisticsPanelProps {
  backStackSize: number;
  forwardStackSize: number;
  queueSize: number;
  totalOperations: number;
}

export function StatisticsPanel({ backStackSize, forwardStackSize, queueSize, totalOperations }: StatisticsPanelProps) {
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3">
        <BarChart3 className="w-4 h-4" />
        <h4>Statistics</h4>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center">
          <p className="text-2xl font-semibold text-emerald-600">{backStackSize}</p>
          <p className="text-xs text-muted-foreground">Back Stack</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-semibold text-amber-600">{forwardStackSize}</p>
          <p className="text-xs text-muted-foreground">Forward Stack</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-semibold text-purple-600">{queueSize}</p>
          <p className="text-xs text-muted-foreground">Queue Size</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-semibold text-blue-600">{totalOperations}</p>
          <p className="text-xs text-muted-foreground">Operations</p>
        </div>
      </div>
    </Card>
  );
}
