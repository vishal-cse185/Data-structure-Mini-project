# Test Cases for Browser & Crawler System

## Test Case 1: Visit Page Operation
**Objective**: Verify that visiting a new page works correctly

**Steps**:
1. Start the program
2. Select option [1] - Visit New Page
3. Enter URL: `https://google.com`
4. Select option [6] - Display System State

**Expected Result**:
- Current page should be `https://google.com`
- Back Stack should contain `https://example.com`
- Forward Stack should be empty
- Operation count should increment

---

## Test Case 2: Back Navigation (Stack Pop)
**Objective**: Test stack pop operation on Back Stack

**Steps**:
1. Load demo data (Option 7)
2. Current page: `https://wikipedia.org`
3. Select option [2] - Go Back
4. Display state

**Expected Result**:
- Current page should be `https://stackoverflow.com` (popped from Back Stack)
- Forward Stack should contain `https://wikipedia.org`
- Back Stack should have 2 remaining items

---

## Test Case 3: Forward Navigation (Stack Pop)
**Objective**: Test stack pop operation on Forward Stack

**Steps**:
1. Load demo data
2. Go back once (creates entry in Forward Stack)
3. Select option [3] - Go Forward
4. Display state

**Expected Result**:
- Current page should return to `https://wikipedia.org`
- Forward Stack should be empty
- Back Stack should have 3 items again

---

## Test Case 4: Queue Enqueue Operation
**Objective**: Test adding URLs to crawler queue

**Steps**:
1. Reset system (Option 8)
2. Select option [4] - Add URL to Crawler Queue
3. Enter URL: `https://python.org`
4. Repeat with `https://javascript.info`
5. Display state

**Expected Result**:
- Crawler Queue should contain 2 items
- Front: `https://python.org`
- Rear: `https://javascript.info`

---

## Test Case 5: Queue Dequeue Operation
**Objective**: Test crawling (dequeue) from crawler queue

**Steps**:
1. Load demo data (3 URLs in queue)
2. Select option [5] - Crawl Next URL
3. Display state

**Expected Result**:
- Current page should be `https://docs.python.org` (dequeued)
- Crawler Queue should have 2 remaining items
- Back Stack should contain previous current page
- Forward Stack should be empty

---

## Test Case 6: Stack Underflow Handling
**Objective**: Test error handling for empty stack

**Steps**:
1. Reset system
2. Try to go back (Option 2) when Back Stack is empty
3. Try to go forward (Option 3) when Forward Stack is empty

**Expected Result**:
- Error message: "No pages in Back Stack! Cannot go back."
- Error message: "No pages in Forward Stack! Cannot go forward."
- No crash or undefined behavior

---

## Test Case 7: Queue Underflow Handling
**Objective**: Test error handling for empty queue

**Steps**:
1. Reset system
2. Select option [5] - Crawl Next (when queue is empty)

**Expected Result**:
- Error message: "Crawler Queue is empty! No URLs to crawl."
- No crash or undefined behavior

---

## Test Case 8: Visit Page Clears Forward Stack
**Objective**: Verify that visiting new page clears forward history

**Steps**:
1. Load demo data
2. Go back twice (creates Forward Stack entries)
3. Visit new page: `https://newsite.com`
4. Display state

**Expected Result**:
- Current page: `https://newsite.com`
- Forward Stack should be empty (cleared)
- Back Stack should contain previous current page

---

## Test Case 9: Multiple Operations Sequence
**Objective**: Test complex operation sequence

**Steps**:
1. Load demo data
2. Go back (2 times)
3. Go forward (1 time)
4. Add URL to queue: `https://test.com`
5. Crawl next URL
6. Display state

**Expected Result**:
- All operations complete successfully
- Data structures maintain correct state
- Operation count correctly incremented

---

## Test Case 10: Stack Overflow
**Objective**: Test stack overflow handling (if MAX_STACK_SIZE is small)

**Steps**:
1. Visit 101 different pages (if MAX_STACK_SIZE = 100)
2. Observe behavior

**Expected Result**:
- Error message: "Stack Overflow! Cannot push more items."
- Program continues to run normally

---

## Test Case 11: Reset Functionality
**Objective**: Test system reset

**Steps**:
1. Load demo data
2. Perform several operations
3. Select option [8] - Reset System
4. Display state

**Expected Result**:
- Current page: `https://example.com`
- All stacks empty
- Queue empty
- Operation count reset to 0

---

## Test Case 12: Load Demo Data
**Objective**: Test demo data loading

**Steps**:
1. Select option [7] - Load Demo Data
2. Display state

**Expected Result**:
- Current page: `https://wikipedia.org`
- Back Stack contains 3 URLs:
  - `https://stackoverflow.com`
  - `https://github.com`
  - `https://google.com`
- Crawler Queue contains 3 URLs:
  - `https://docs.python.org`
  - `https://reactjs.org`
  - `https://nodejs.org`

---

## Test Case 13: Operation Logging
**Objective**: Verify operation logging works correctly

**Steps**:
1. Perform any operation (e.g., visit page)
2. Check console output

**Expected Result**:
- Log message displayed with:
  - Operation number
  - Timestamp
  - Operation type
  - Description

---

## Test Case 14: Invalid Input Handling
**Objective**: Test handling of invalid menu choices

**Steps**:
1. Enter invalid number (e.g., 99)
2. Enter non-numeric input (e.g., "abc")
3. Enter negative number

**Expected Result**:
- Appropriate error messages
- Program doesn't crash
- User can continue using the program

---

## Test Case 15: Empty URL Handling
**Objective**: Test validation of empty URLs

**Steps**:
1. Select Visit Page
2. Press Enter without entering URL
3. Same for Add to Queue

**Expected Result**:
- Error message: "Please enter a valid URL!"
- Operation cancelled
- System state unchanged

---

## Performance Tests

### Test P1: Large Number of Operations
- Perform 1000 operations
- Verify no memory leaks
- Check performance degradation

### Test P2: Boundary Conditions
- Fill stack to MAX_STACK_SIZE - 1
- Fill queue to MAX_QUEUE_SIZE - 1
- Add one more item (should succeed)
- Add another (should fail with overflow)

### Test P3: Alternating Operations
- Visit → Back → Forward → Visit (repeat 100 times)
- Verify stack operations remain consistent

---

## Edge Cases

### Edge Case 1: Single Element Stack
- Push one element
- Pop it
- Verify stack is empty
- Try to pop again (should show underflow)

### Edge Case 2: Circular Queue Wraparound
- Fill queue completely
- Dequeue all items
- Enqueue new items (should use circular behavior)

### Edge Case 3: Very Long URLs
- Enter URL with 255 characters (MAX_URL_LENGTH - 1)
- Verify it's stored correctly
- Enter URL > 256 characters
- Verify truncation behavior

---

## Integration Tests

### Integration Test 1: Full User Journey
```
1. Load Demo → Display
2. Back → Back → Display
3. Forward → Display
4. Visit New Page → Display
5. Crawl Next → Display
6. Add to Queue → Display
7. Reset → Display
```

All operations should work seamlessly together.

### Integration Test 2: Error Recovery
```
1. Try invalid operations (underflow scenarios)
2. Perform valid operations
3. Verify system recovered properly
```

---

## Expected Console Output Example

```
[LOG 1] [Fri Oct  3 10:30:45 2025] VISIT: Visited 'https://google.com' - Pushed old page to Back Stack, cleared Forward Stack

✓ Successfully visited: https://google.com
  → Current page pushed to Back Stack
  → Forward Stack cleared
```

---

## Testing Checklist

- [ ] All menu options work correctly
- [ ] Stack push/pop operations verified
- [ ] Queue enqueue/dequeue operations verified
- [ ] Error handling works (overflow/underflow)
- [ ] Invalid input handled gracefully
- [ ] Operations logging works
- [ ] Display functions show correct state
- [ ] Demo data loads correctly
- [ ] Reset clears all data
- [ ] Help information displays properly
- [ ] Exit works cleanly
- [ ] No memory leaks
- [ ] No segmentation faults
- [ ] No buffer overflows
