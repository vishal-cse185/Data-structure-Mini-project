# Makefile for Web Browser & Crawler System

# Compiler
CC = gcc

# Compiler flags
CFLAGS = -Wall -Wextra -std=c99

# Target executable
TARGET = browser_crawler

# Source files
SOURCES = browser_crawler.c

# Object files
OBJECTS = $(SOURCES:.c=.o)

# Default target
all: $(TARGET)

# Build the executable
$(TARGET): $(SOURCES)
	$(CC) $(CFLAGS) -o $(TARGET) $(SOURCES)
	@echo "Build successful! Run with: ./$(TARGET)"

# Clean build files
clean:
	rm -f $(TARGET) $(OBJECTS)
	@echo "Clean complete!"

# Run the program
run: $(TARGET)
	./$(TARGET)

# Debug build
debug: CFLAGS += -g -O0
debug: clean $(TARGET)
	@echo "Debug build complete! Run with: gdb ./$(TARGET)"

# Help
help:
	@echo "Available targets:"
	@echo "  make          - Build the program"
	@echo "  make run      - Build and run the program"
	@echo "  make clean    - Remove build files"
	@echo "  make debug    - Build with debug symbols"
	@echo "  make help     - Show this help message"

.PHONY: all clean run debug help
