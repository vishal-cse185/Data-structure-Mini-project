/*
 * Web Browser & Crawler System - C Implementation
 * Demonstrates Stack (LIFO) and Queue (FIFO) Data Structures
 * 
 * Features:
 * - Browser History using Stacks (Back/Forward)
 * - Web Crawler Queue using Queue (FIFO)
 * - Interactive menu-driven interface
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_URL_LENGTH 256
#define MAX_STACK_SIZE 100
#define MAX_QUEUE_SIZE 100

// ============================================================================
// STACK IMPLEMENTATION (For Browser History)
// ============================================================================

typedef struct {
    char urls[MAX_STACK_SIZE][MAX_URL_LENGTH];
    int top;
} Stack;

// Initialize stack
void initStack(Stack *s) {
    s->top = -1;
}

// Check if stack is empty
int isEmpty(Stack *s) {
    return s->top == -1;
}

// Check if stack is full
int isFull(Stack *s) {
    return s->top == MAX_STACK_SIZE - 1;
}

// Push to stack
int push(Stack *s, const char *url) {
    if (isFull(s)) {
        printf("\n[ERROR] Stack Overflow! Cannot push more items.\n");
        return 0;
    }
    s->top++;
    strcpy(s->urls[s->top], url);
    return 1;
}

// Pop from stack
int pop(Stack *s, char *url) {
    if (isEmpty(s)) {
        printf("\n[ERROR] Stack Underflow! Stack is empty.\n");
        return 0;
    }
    strcpy(url, s->urls[s->top]);
    s->top--;
    return 1;
}

// Peek at top of stack
int peek(Stack *s, char *url) {
    if (isEmpty(s)) {
        return 0;
    }
    strcpy(url, s->urls[s->top]);
    return 1;
}

// Display stack contents
void displayStack(Stack *s, const char *name, const char *color) {
    printf("\n%s [%s] (LIFO - Last In First Out)\n", color, name);
    printf("===========================================\n");
    if (isEmpty(s)) {
        printf("  [Empty - No items in stack]\n");
    } else {
        printf("  Top -> ");
        for (int i = s->top; i >= 0; i--) {
            printf("\n  [%d] %s", i, s->urls[i]);
        }
        printf("\n  Size: %d items\n", s->top + 1);
    }
    printf("===========================================\n");
}

// ============================================================================
// QUEUE IMPLEMENTATION (For Web Crawler)
// ============================================================================

typedef struct {
    char urls[MAX_QUEUE_SIZE][MAX_URL_LENGTH];
    int front;
    int rear;
    int count;
} Queue;

// Initialize queue
void initQueue(Queue *q) {
    q->front = 0;
    q->rear = -1;
    q->count = 0;
}

// Check if queue is empty
int isQueueEmpty(Queue *q) {
    return q->count == 0;
}

// Check if queue is full
int isQueueFull(Queue *q) {
    return q->count == MAX_QUEUE_SIZE;
}

// Enqueue (add to rear)
int enqueue(Queue *q, const char *url) {
    if (isQueueFull(q)) {
        printf("\n[ERROR] Queue Overflow! Cannot enqueue more items.\n");
        return 0;
    }
    q->rear = (q->rear + 1) % MAX_QUEUE_SIZE;
    strcpy(q->urls[q->rear], url);
    q->count++;
    return 1;
}

// Dequeue (remove from front)
int dequeue(Queue *q, char *url) {
    if (isQueueEmpty(q)) {
        printf("\n[ERROR] Queue Underflow! Queue is empty.\n");
        return 0;
    }
    strcpy(url, q->urls[q->front]);
    q->front = (q->front + 1) % MAX_QUEUE_SIZE;
    q->count--;
    return 1;
}

// Display queue contents
void displayQueue(Queue *q, const char *name, const char *color) {
    printf("\n%s [%s] (FIFO - First In First Out)\n", color, name);
    printf("===========================================\n");
    if (isQueueEmpty(q)) {
        printf("  [Empty - No URLs waiting to be crawled]\n");
    } else {
        printf("  Front -> ");
        int index = q->front;
        for (int i = 0; i < q->count; i++) {
            printf("\n  [%d] %s", i, q->urls[index]);
            index = (index + 1) % MAX_QUEUE_SIZE;
        }
        printf(" <- Rear\n");
        printf("  Size: %d items\n", q->count);
    }
    printf("===========================================\n");
}

// ============================================================================
// BROWSER & CRAWLER SYSTEM
// ============================================================================

typedef struct {
    char currentPage[MAX_URL_LENGTH];
    Stack backStack;
    Stack forwardStack;
    Queue crawlerQueue;
    int operationCount;
} BrowserSystem;

// Initialize browser system
void initBrowserSystem(BrowserSystem *browser) {
    strcpy(browser->currentPage, "https://example.com");
    initStack(&browser->backStack);
    initStack(&browser->forwardStack);
    initQueue(&browser->crawlerQueue);
    browser->operationCount = 0;
}

// Log operation
void logOperation(BrowserSystem *browser, const char *operation, const char *description) {
    time_t now;
    time(&now);
    char *timestamp = ctime(&now);
    timestamp[strlen(timestamp) - 1] = '\0'; // Remove newline
    
    printf("\n[LOG %d] [%s] %s: %s\n", 
           ++browser->operationCount, timestamp, operation, description);
}

// Visit new page
void visitPage(BrowserSystem *browser, const char *url) {
    if (strlen(url) == 0) {
        printf("\n[ERROR] Please enter a valid URL!\n");
        return;
    }
    
    // Push current page to back stack
    push(&browser->backStack, browser->currentPage);
    
    // Clear forward stack (visiting new page clears forward history)
    initStack(&browser->forwardStack);
    
    // Update current page
    strcpy(browser->currentPage, url);
    
    char logMsg[512];
    sprintf(logMsg, "Visited '%s' - Pushed old page to Back Stack, cleared Forward Stack", url);
    logOperation(browser, "VISIT", logMsg);
    
    printf("\n✓ Successfully visited: %s\n", url);
    printf("  → Current page pushed to Back Stack\n");
    printf("  → Forward Stack cleared\n");
}

// Go back
void goBack(BrowserSystem *browser) {
    char previousPage[MAX_URL_LENGTH];
    
    if (!pop(&browser->backStack, previousPage)) {
        printf("\n[INFO] No pages in Back Stack! Cannot go back.\n");
        return;
    }
    
    // Push current page to forward stack
    push(&browser->forwardStack, browser->currentPage);
    
    // Update current page
    strcpy(browser->currentPage, previousPage);
    
    char logMsg[512];
    sprintf(logMsg, "Went back to '%s' - Popped from Back Stack, pushed to Forward Stack", previousPage);
    logOperation(browser, "BACK", logMsg);
    
    printf("\n✓ Went back to: %s\n", previousPage);
    printf("  → Popped from Back Stack\n");
    printf("  → Old page pushed to Forward Stack\n");
}

// Go forward
void goForward(BrowserSystem *browser) {
    char nextPage[MAX_URL_LENGTH];
    
    if (!pop(&browser->forwardStack, nextPage)) {
        printf("\n[INFO] No pages in Forward Stack! Cannot go forward.\n");
        return;
    }
    
    // Push current page to back stack
    push(&browser->backStack, browser->currentPage);
    
    // Update current page
    strcpy(browser->currentPage, nextPage);
    
    char logMsg[512];
    sprintf(logMsg, "Went forward to '%s' - Popped from Forward Stack, pushed to Back Stack", nextPage);
    logOperation(browser, "FORWARD", logMsg);
    
    printf("\n✓ Went forward to: %s\n", nextPage);
    printf("  → Popped from Forward Stack\n");
    printf("  → Old page pushed to Back Stack\n");
}

// Add URL to crawler queue
void addToCrawlerQueue(BrowserSystem *browser, const char *url) {
    if (strlen(url) == 0) {
        printf("\n[ERROR] Please enter a valid URL!\n");
        return;
    }
    
    if (enqueue(&browser->crawlerQueue, url)) {
        char logMsg[512];
        sprintf(logMsg, "Added '%s' to Crawler Queue - Enqueued at rear", url);
        logOperation(browser, "ENQUEUE", logMsg);
        
        printf("\n✓ Added to Crawler Queue: %s\n", url);
        printf("  → Enqueued at rear of queue\n");
    }
}

// Crawl next URL from queue
void crawlNext(BrowserSystem *browser) {
    char nextUrl[MAX_URL_LENGTH];
    
    if (!dequeue(&browser->crawlerQueue, nextUrl)) {
        printf("\n[INFO] Crawler Queue is empty! No URLs to crawl.\n");
        return;
    }
    
    // Push current page to back stack
    push(&browser->backStack, browser->currentPage);
    
    // Clear forward stack
    initStack(&browser->forwardStack);
    
    // Update current page
    strcpy(browser->currentPage, nextUrl);
    
    char logMsg[512];
    sprintf(logMsg, "Crawled '%s' - Dequeued from front, pushed to Back Stack", nextUrl);
    logOperation(browser, "CRAWL", logMsg);
    
    printf("\n✓ Crawled: %s\n", nextUrl);
    printf("  → Dequeued from front of queue\n");
    printf("  → Old page pushed to Back Stack\n");
    printf("  → Forward Stack cleared\n");
}

// Display current system state
void displaySystemState(BrowserSystem *browser) {
    printf("\n");
    printf("╔═══════════════════════════════════════════════════════════╗\n");
    printf("║        WEB BROWSER & CRAWLER SYSTEM - CURRENT STATE       ║\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n");
    
    printf("\n[CURRENT PAGE] 🌐\n");
    printf("===========================================\n");
    printf("  %s\n", browser->currentPage);
    printf("===========================================\n");
    
    // Display stacks
    displayStack(&browser->backStack, "BACK STACK", "🟢");
    displayStack(&browser->forwardStack, "FORWARD STACK", "🟠");
    
    // Display queue
    displayQueue(&browser->crawlerQueue, "CRAWLER QUEUE", "🟣");
    
    printf("\n[STATISTICS] 📊\n");
    printf("===========================================\n");
    printf("  Back Stack Size: %d\n", browser->backStack.top + 1);
    printf("  Forward Stack Size: %d\n", browser->forwardStack.top + 1);
    printf("  Crawler Queue Size: %d\n", browser->crawlerQueue.count);
    printf("  Total Operations: %d\n", browser->operationCount);
    printf("===========================================\n");
}

// Load demo data
void loadDemoData(BrowserSystem *browser) {
    // Reset system
    initBrowserSystem(browser);
    
    // Set current page
    strcpy(browser->currentPage, "https://wikipedia.org");
    
    // Add to back stack
    push(&browser->backStack, "https://google.com");
    push(&browser->backStack, "https://github.com");
    push(&browser->backStack, "https://stackoverflow.com");
    
    // Add to crawler queue
    enqueue(&browser->crawlerQueue, "https://docs.python.org");
    enqueue(&browser->crawlerQueue, "https://reactjs.org");
    enqueue(&browser->crawlerQueue, "https://nodejs.org");
    
    logOperation(browser, "DEMO", "Loaded demo data with sample URLs");
    
    printf("\n✓ Demo data loaded successfully!\n");
    printf("  → 3 pages in Back Stack\n");
    printf("  → 3 URLs in Crawler Queue\n");
}

// Display menu
void displayMenu() {
    printf("\n");
    printf("╔═══════════════════════════════════════════════════════════╗\n");
    printf("║           WEB BROWSER & CRAWLER SYSTEM MENU               ║\n");
    printf("╠══════════════════════════════════════════════════��════════╣\n");
    printf("║  [1] Visit New Page          [2] Go Back                  ║\n");
    printf("║  [3] Go Forward              [4] Add URL to Crawler Queue ║\n");
    printf("║  [5] Crawl Next URL          [6] Display System State     ║\n");
    printf("║  [7] Load Demo Data          [8] Reset System             ║\n");
    printf("║  [9] Help/Info               [0] Exit                     ║\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n");
    printf("Enter your choice: ");
}

// Display help
void displayHelp() {
    printf("\n");
    printf("╔═══════════════════════════════════════════════════════════╗\n");
    printf("║                     HELP & INFORMATION                    ║\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n");
    printf("\nDATA STRUCTURES:\n");
    printf("  • STACK (LIFO - Last In First Out)\n");
    printf("    - Back Stack: Stores previously visited pages\n");
    printf("    - Forward Stack: Stores pages for forward navigation\n");
    printf("    - Operations: push(), pop(), peek()\n");
    printf("\n");
    printf("  • QUEUE (FIFO - First In First Out)\n");
    printf("    - Crawler Queue: Stores URLs waiting to be crawled\n");
    printf("    - Operations: enqueue(), dequeue()\n");
    printf("\n");
    printf("OPERATIONS:\n");
    printf("  1. Visit Page: Push current to Back Stack, clear Forward\n");
    printf("  2. Go Back: Pop from Back Stack, push to Forward Stack\n");
    printf("  3. Go Forward: Pop from Forward Stack, push to Back Stack\n");
    printf("  4. Add to Queue: Enqueue URL at rear of Crawler Queue\n");
    printf("  5. Crawl Next: Dequeue from front, visit that URL\n");
    printf("\n");
    printf("EXAMPLE WORKFLOW:\n");
    printf("  1. Load demo data (Option 7)\n");
    printf("  2. Display system state (Option 6)\n");
    printf("  3. Try going back (Option 2)\n");
    printf("  4. Try going forward (Option 3)\n");
    printf("  5. Crawl next URL (Option 5)\n");
    printf("===========================================\n");
}

// ============================================================================
// MAIN PROGRAM
// ============================================================================

int main() {
    BrowserSystem browser;
    initBrowserSystem(&browser);
    
    int choice;
    char url[MAX_URL_LENGTH];
    
    printf("\n");
    printf("╔═══════════════════════════════════════════════════════════╗\n");
    printf("║   WEB BROWSER & CRAWLER SYSTEM - C IMPLEMENTATION         ║\n");
    printf("║   Data Structures: Stack (LIFO) + Queue (FIFO)            ║\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n");
    
    while (1) {
        displayMenu();
        
        if (scanf("%d", &choice) != 1) {
            // Clear invalid input
            while (getchar() != '\n');
            printf("\n[ERROR] Invalid input! Please enter a number.\n");
            continue;
        }
        while (getchar() != '\n'); // Clear newline
        
        switch (choice) {
            case 1: // Visit new page
                printf("\nEnter URL to visit: ");
                fgets(url, MAX_URL_LENGTH, stdin);
                url[strcspn(url, "\n")] = '\0'; // Remove newline
                visitPage(&browser, url);
                break;
                
            case 2: // Go back
                goBack(&browser);
                break;
                
            case 3: // Go forward
                goForward(&browser);
                break;
                
            case 4: // Add to crawler queue
                printf("\nEnter URL to add to crawler queue: ");
                fgets(url, MAX_URL_LENGTH, stdin);
                url[strcspn(url, "\n")] = '\0';
                addToCrawlerQueue(&browser, url);
                break;
                
            case 5: // Crawl next
                crawlNext(&browser);
                break;
                
            case 6: // Display state
                displaySystemState(&browser);
                break;
                
            case 7: // Load demo data
                loadDemoData(&browser);
                displaySystemState(&browser);
                break;
                
            case 8: // Reset system
                initBrowserSystem(&browser);
                printf("\n✓ System reset successfully!\n");
                printf("  → All stacks and queues cleared\n");
                printf("  → Current page: %s\n", browser.currentPage);
                break;
                
            case 9: // Help
                displayHelp();
                break;
                
            case 0: // Exit
                printf("\n");
                printf("╔═══════════════════════════════════════════════════════════╗\n");
                printf("║           Thank you for using the Browser System!         ║\n");
                printf("║                    Goodbye! 👋                            ║\n");
                printf("╚═══════════════════════════════════════════════════════════╝\n");
                printf("\n");
                return 0;
                
            default:
                printf("\n[ERROR] Invalid choice! Please select 0-9.\n");
        }
    }
    
    return 0;
}
