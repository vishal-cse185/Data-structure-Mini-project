# Web Browser & Crawler System - C Backend Implementation

This is a complete C implementation of the Browser and Crawler system that demonstrates **Stack** and **Queue** data structures.

## 📚 Data Structures

### Stack (LIFO - Last In First Out)
- **Back Stack**: Stores previously visited pages for backward navigation
- **Forward Stack**: Stores pages for forward navigation
- **Operations**: `push()`, `pop()`, `peek()`, `isEmpty()`, `isFull()`

### Queue (FIFO - First In First Out)
- **Crawler Queue**: Stores URLs waiting to be crawled
- **Operations**: `enqueue()`, `dequeue()`, `isEmpty()`, `isFull()`

## 🚀 Compilation & Execution

### On Linux/macOS:
```bash
gcc browser_crawler.c -o browser_crawler
./browser_crawler
```

### On Windows:
```bash
gcc browser_crawler.c -o browser_crawler.exe
browser_crawler.exe
```

### Using Make (Optional):
```bash
make
./browser_crawler
```

## 📋 Features

1. **Visit New Page**: Navigate to a new URL (pushes current page to Back Stack, clears Forward Stack)
2. **Go Back**: Navigate to previous page (pops from Back Stack, pushes to Forward Stack)
3. **Go Forward**: Navigate to next page (pops from Forward Stack, pushes to Back Stack)
4. **Add URL to Crawler Queue**: Enqueue a URL for crawling
5. **Crawl Next URL**: Dequeue and visit the next URL from the crawler queue
6. **Display System State**: Show current page, both stacks, and queue
7. **Load Demo Data**: Populate system with sample data
8. **Reset System**: Clear all data structures
9. **Help/Info**: Display detailed information about operations

## 🎯 How It Works

### Browser Navigation (Stacks)

When you **visit a new page**:
1. Current page → **pushed** to Back Stack
2. Forward Stack → **cleared**
3. New page becomes current

When you **go back**:
1. Previous page ← **popped** from Back Stack
2. Current page → **pushed** to Forward Stack
3. Previous page becomes current

When you **go forward**:
1. Next page ← **popped** from Forward Stack
2. Current page → **pushed** to Back Stack
3. Next page becomes current

### Web Crawler (Queue)

When you **add URL to queue**:
1. URL → **enqueued** at rear of queue

When you **crawl next**:
1. URL ← **dequeued** from front of queue
2. Current page → **pushed** to Back Stack
3. Forward Stack → **cleared**
4. Dequeued URL becomes current page

## 📊 Example Usage

```
1. Select option [7] to load demo data
2. Select option [6] to display system state
3. Select option [2] to go back (pops from Back Stack)
4. Select option [3] to go forward (pops from Forward Stack)
5. Select option [5] to crawl next URL (dequeues from Queue)
6. Select option [6] to see updated state
```

## 🔧 Code Structure

### Main Components:

- **Stack Structure**: Array-based stack implementation
- **Queue Structure**: Circular array-based queue implementation
- **BrowserSystem Structure**: Contains current page, stacks, and queue
- **Operation Functions**: visitPage(), goBack(), goForward(), etc.
- **Display Functions**: Show current state with visual formatting
- **Menu System**: Interactive command-line interface

### Key Functions:

```c
// Stack Operations
void initStack(Stack *s);
int push(Stack *s, const char *url);
int pop(Stack *s, char *url);
void displayStack(Stack *s, const char *name, const char *color);

// Queue Operations
void initQueue(Queue *q);
int enqueue(Queue *q, const char *url);
int dequeue(Queue *q, char *url);
void displayQueue(Queue *q, const char *name, const char *color);

// Browser Operations
void visitPage(BrowserSystem *browser, const char *url);
void goBack(BrowserSystem *browser);
void goForward(BrowserSystem *browser);
void addToCrawlerQueue(BrowserSystem *browser, const char *url);
void crawlNext(BrowserSystem *browser);
```

## 📝 Implementation Details

### Stack Implementation
- **Type**: Array-based stack
- **Capacity**: 100 URLs
- **Top pointer**: Tracks the top element
- **Overflow/Underflow**: Proper error handling

### Queue Implementation
- **Type**: Circular array-based queue
- **Capacity**: 100 URLs
- **Front & Rear pointers**: Track queue boundaries
- **Circular behavior**: Efficient space utilization
- **Overflow/Underflow**: Proper error handling

## 🎓 Educational Value

This implementation demonstrates:
- **Stack (LIFO)**: Browser history management
- **Queue (FIFO)**: Web crawler URL scheduling
- **Memory management**: Fixed-size arrays
- **Error handling**: Overflow/underflow conditions
- **Real-world application**: Browser navigation and web crawling

## 📖 Constants

```c
#define MAX_URL_LENGTH 256    // Maximum URL string length
#define MAX_STACK_SIZE 100    // Maximum stack capacity
#define MAX_QUEUE_SIZE 100    // Maximum queue capacity
```

## 🐛 Error Handling

The program handles:
- Stack overflow (too many pushes)
- Stack underflow (pop from empty stack)
- Queue overflow (too many enqueues)
- Queue underflow (dequeue from empty queue)
- Invalid user input
- Empty URL strings

## 💡 Tips for Classroom Demonstration

1. Start with **demo data** to show pre-populated state
2. Use **display state** frequently to visualize changes
3. Try **going back** multiple times to see stack behavior
4. Try **going forward** to demonstrate the forward stack
5. **Add URLs** to queue and then crawl them sequentially
6. Show **error handling** by trying to go back/forward when stacks are empty

## 📄 License

This code is provided for educational purposes to demonstrate data structures in action.
